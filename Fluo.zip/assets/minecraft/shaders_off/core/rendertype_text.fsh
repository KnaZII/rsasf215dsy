#version 150
#define FSH
#define RENDERTYPE_TEXT

#moj_import <fog.glsl>

// These are inputs and outputs to the shader
// If you are merging with a shader, put any inputs and outputs that they have, but are not here already, in the list below
uniform sampler2D Sampler0;

uniform vec4 ColorModulator;
uniform float FogStart;
uniform float FogEnd;
uniform vec4 FogColor;
uniform float GameTime;
uniform vec2 ScreenSize;

in float vertexDistance;
in float depthLevel;
in vec4 vertexColor;
in vec2 texCoord0;
in vec4 baseColor;
in vec4 lightColor;
in float yPosition;

out vec4 fragColor;

#moj_import <spheya_packs_impl.glsl>

void main() {
    if(applySpheyaPacks()) return;

    // Code below here is vanilla rendering, 
    // If you are merging with another shader, replace the code below here with the code that they have in their main() function

    vec4 color = texture(Sampler0, texCoord0) * vertexColor * ColorModulator;
	
	vec4 pureColor = texture(Sampler0, texCoord0);

	if (color.a < 0.05) {
		discard;
	}
	
	vec3 light = vec3(0.25, 0.25, 0.25);
	vec3 shadow = vec3(0.248, 0.248, 0.248);
	
	//remove shadow from all non-chat/non-hover text (level = 0) and don't remove dark_gray UI/inventory text
	if (depthLevel == 0 && lessThan(vertexColor.rgb,shadow) == bvec3(true)) {
		if(yPosition > 0.8){
			if((color.r > 0 && color.r < 0.001 && color.g == 0 && color.b == 0) || (pureColor.r > 0.99 && pureColor.r < 1 && pureColor.g == 1 && pureColor.b == 1)){
				// ОСТАВЛЯЕМ ТЕНЬ
			}else{
				discard;
			}
		}
		//discard;
	}
	
	//remove shadow from chat text
	if (depthLevel == 100) {
		//discard;
	}
	
	//remove shadow from hover text
	if (depthLevel == 400) {
		//discard;
	}
	
  fragColor = linear_fog(color, vertexDistance, FogStart, FogEnd, FogColor);
}
