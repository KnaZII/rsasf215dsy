// Все эффекты переведены на «тёмные» триггеры с шагом 4.
// Шаблон: TEXT_EFFECT(4, 4, B) где B = (N-1)*4 + 4 ; #000000 не используем.
// Визуальный цвет задаётся внутри блоков эффектов (override_text_color/gradients/...).
// Общее количество эффектов: 68

// ============================================
// Категория: Радуга (1-4)
// ============================================

// 1 — #040404  (Вращающаяся радуга)
TEXT_EFFECT(4, 4, 4) { // trigger #040404
    apply_rainbow();
    apply_waving_movement(1.2, 2.0);
}

// 2 — #040408  (Радуга)
TEXT_EFFECT(4, 4, 8) { // trigger #040408
    apply_rainbow();
}

// 3 — #04040C  (Радужная комета)
TEXT_EFFECT(4, 4, 12) { // trigger #04040C
    apply_rainbow();
    apply_iterating_movement(1.4, 1.6);
    apply_waving_movement(1.2, 2.4);
    apply_thin_outline(rgb(120, 60, 20));
    override_shadow_color(rgb(90, 40, 10));
}

// 4 — #040410  (Радужный градиент)
TEXT_EFFECT(4, 4, 16) { // trigger #040410
    apply_gradient(rgb(255, 0, 128), rgb(0, 255, 255));
    apply_waving_movement(1.0, 1.5);
    override_shadow_color(rgb(60, 0, 40));
}

// ============================================
// Категория: Простые блески (5-23)
// ============================================

// 5 — #040414  (Золотой блеск)
TEXT_EFFECT(4, 4, 20) { // trigger #040414
    apply_shimmer(0.8, 0.8);
    override_text_color(rgb(255, 215, 0));
    override_shadow_color(rgb(120, 100, 0));
}

// 6 — #040418  (Ледяной блеск)
TEXT_EFFECT(4, 4, 24) { // trigger #040418
    apply_shimmer(1.2, 0.6);
    override_text_color(rgb(120, 220, 255));
    override_shadow_color(rgb(30, 80, 100));
}

// 7 — #04041C  (Мерцающий розовый)
TEXT_EFFECT(4, 4, 28) { // trigger #04041C
    apply_shimmer(1.0, 0.7);
    override_text_color(rgb(255, 80, 180));
    override_shadow_color(rgb(80, 20, 60));
}

// --- Minecraft Shimmers ---

// 8 — #040420  (Белый блеск)
TEXT_EFFECT(4, 4, 32) { // trigger #040420
    apply_shimmer(0.5, 0.2);
    override_text_color(rgb(249, 255, 254)); // 0xF9FFFE
    override_shadow_color(rgb(120, 120, 120)); // Custom dark shadow
}

// 9 — #040424  (Светло-серый блеск)
TEXT_EFFECT(4, 4, 36) { // trigger #040424
    apply_shimmer(0.5, 0.2);
    override_text_color(rgb(157, 157, 151)); // 0x9D9D97
    override_shadow_color(rgb(75, 75, 70)); // Custom dark shadow
}

// 10 — #040428  (Серый блеск)
TEXT_EFFECT(4, 4, 40) { // trigger #040428
    apply_shimmer(0.5, 0.2);
    override_text_color(rgb(71, 79, 82)); // 0x474F52
    override_shadow_color(rgb(35, 40, 42)); // Custom dark shadow
}

// 11 — #04042C  (Чёрный блеск)
TEXT_EFFECT(4, 4, 44) { // trigger #04042C
    apply_shimmer(0.5, 0.2);
    override_text_color(rgb(29, 29, 33)); // 0x1D1D21
    override_shadow_color(rgb(10, 10, 12)); // Custom dark shadow
}

// 12 — #040430  (Коричневый блеск)
TEXT_EFFECT(4, 4, 48) { // trigger #040430
    apply_shimmer(0.5, 0.2);
    override_text_color(rgb(131, 84, 50)); // 0x835432
    override_shadow_color(rgb(65, 40, 25)); // Custom dark shadow
}

// 13 — #040434  (Красный блеск)
TEXT_EFFECT(4, 4, 52) { // trigger #040434
    apply_shimmer(0.5, 0.2);
    override_text_color(rgb(176, 46, 38)); // 0xB02E26
    override_shadow_color(rgb(80, 20, 15)); // Custom dark shadow
}

// 14 — #040438  (Оранжевый блеск)
TEXT_EFFECT(4, 4, 56) { // trigger #040438
    apply_shimmer(0.5, 0.2);
    override_text_color(rgb(249, 128, 29)); // 0xF9801D
    override_shadow_color(rgb(120, 60, 10)); // Custom dark shadow
}

// 15 — #04043C  (Жёлтый блеск)
TEXT_EFFECT(4, 4, 60) { // trigger #04043C
    apply_shimmer(0.5, 0.2);
    override_text_color(rgb(254, 216, 61)); // 0xFED83D
    override_shadow_color(rgb(120, 100, 25)); // Custom dark shadow
}

// 16 — #040440  (Лаймовый блеск)
TEXT_EFFECT(4, 4, 64) { // trigger #040440
    apply_shimmer(0.5, 0.2);
    override_text_color(rgb(128, 199, 31)); // 0x80C71F
    override_shadow_color(rgb(60, 90, 10)); // Custom dark shadow
}

// 17 — #040444  (Зелёный блеск)
TEXT_EFFECT(4, 4, 68) { // trigger #040444
    apply_shimmer(0.5, 0.2);
    override_text_color(rgb(94, 124, 22)); // 0x5E7C16
    override_shadow_color(rgb(45, 60, 10)); // Custom dark shadow
}

// 18 — #040448  (Голубой блеск)
TEXT_EFFECT(4, 4, 72) { // trigger #040448
    apply_shimmer(0.5, 0.2);
    override_text_color(rgb(58, 179, 218)); // 0x3AB3DA
    override_shadow_color(rgb(25, 80, 100)); // Custom dark shadow
}

// 19 — #04044C  (Бирюзовый блеск)
TEXT_EFFECT(4, 4, 76) { // trigger #04044C
    apply_shimmer(0.5, 0.2);
    override_text_color(rgb(22, 156, 156)); // 0x169C9C
    override_shadow_color(rgb(10, 70, 70)); // Custom dark shadow
}

// 20 — #040450  (Синий блеск)
TEXT_EFFECT(4, 4, 80) { // trigger #040450
    apply_shimmer(0.5, 0.2);
    override_text_color(rgb(60, 68, 170)); // 0x3C44AA
    override_shadow_color(rgb(25, 30, 80)); // Custom dark shadow
}

// 21 — #040454  (Фиолетовый блеск)
TEXT_EFFECT(4, 4, 84) { // trigger #040454
    apply_shimmer(0.5, 0.2);
    override_text_color(rgb(137, 50, 184)); // 0x8932B8
    override_shadow_color(rgb(60, 20, 80)); // Custom dark shadow
}

// 22 — #040458  (Пурпурный блеск)
TEXT_EFFECT(4, 4, 88) { // trigger #040458
    apply_shimmer(0.5, 0.2);
    override_text_color(rgb(199, 78, 189)); // 0xC74EBD
    override_shadow_color(rgb(90, 35, 85)); // Custom dark shadow
}

// 23 — #04045C  (Розовый блеск)
TEXT_EFFECT(4, 4, 92) { // trigger #04045C
    apply_shimmer(0.5, 0.2);
    override_text_color(rgb(243, 139, 170)); // 0xF38BAA
    override_shadow_color(rgb(110, 60, 75)); // Custom dark shadow
}

// ============================================
// Категория: Металлический блеск (24-31)
// ============================================

// 24 — #040460  (Стальной блеск)
TEXT_EFFECT(4, 4, 96) { // trigger #040460
    apply_metalic(rgb(230, 230, 240), rgb(120, 120, 140));
    apply_outline(rgb(70, 80, 100));
    override_shadow_color(rgb(50, 60, 70));
    apply_shimmer(0.7, 0.2);
}

// 25 — #040464  (Золотой металлик)
TEXT_EFFECT(4, 4, 100) { // trigger #040464
    apply_metalic(rgb(255, 240, 150), rgb(150, 120, 0));
    apply_outline(rgb(120, 100, 0));
    override_text_color(rgb(255, 215, 0));
    override_shadow_color(rgb(80, 70, 0));
    apply_shimmer(0.7, 0.9);
}

// 26 — #040468  (Алмазный блеск)
TEXT_EFFECT(4, 4, 104) { // trigger #040468
    apply_metalic(rgb(200, 255, 250), rgb(80, 180, 170));
    apply_outline(rgb(40, 100, 95));
    override_text_color(rgb(91, 217, 209));
    override_shadow_color(rgb(30, 80, 75));
    apply_shimmer(0.7, 0.9);
}

// 27 — #04046C  (Медный блеск)
TEXT_EFFECT(4, 4, 108) { // trigger #04046C
    apply_metalic(rgb(211, 108, 67), rgb(211, 108, 67));
    apply_outline(rgb(148, 81, 48));
    override_text_color(rgb(211, 108, 67));
    override_shadow_color(rgb(146, 74, 39));
    apply_shimmer(0.7, 0.5);
}

// 28 — #040470  (Редстоун блеск)
TEXT_EFFECT(4, 4, 112) { // trigger #040470
    apply_metalic(rgb(255, 100, 100), rgb(150, 0, 0));
    apply_outline(rgb(120, 0, 0));
    override_text_color(rgb(255, 0, 0));
    override_shadow_color(rgb(80, 0, 0));
    apply_shimmer(0.5, 0.3);
}

// 29 — #040474  (Лазуритовый блеск)
TEXT_EFFECT(4, 4, 116) { // trigger #040474
    apply_metalic(rgb(100, 140, 200), rgb(30, 60, 120));
    apply_outline(rgb(15, 30, 60));
    override_text_color(rgb(38, 75, 130));
    override_shadow_color(rgb(10, 20, 45));
    apply_shimmer(0.5, 0.3);
}

// 30 — #040478  (Блеск опыта)
TEXT_EFFECT(4, 4, 120) { // trigger #040478
    apply_metalic(rgb(200, 255, 150), rgb(80, 150, 20));
    apply_outline(rgb(60, 120, 10));
    override_text_color(rgb(130, 255, 30));
    override_shadow_color(rgb(50, 100, 5));
    apply_shimmer(0.5, 0.9);
}

// 31 — #04047C  (Супернова)
TEXT_EFFECT(4, 4, 124) { // trigger #04047C
    apply_metalic(rgb(255, 248, 180), rgb(203, 170, 34));
    apply_shimmer(1.0, 0.7);
    override_shadow_color(rgb(131, 120, 18));
}

// ============================================
// Категория: Огонь и Лава (32-37)
// ============================================

// 32 — #040480  (Огненный оранжевый)
TEXT_EFFECT(4, 4, 128) { // trigger #040480
    apply_fire();
    override_text_color(rgb(255, 100, 0));
    override_shadow_color(rgb(80, 30, 0));
}

// 33 — #040484  (Огненно-красная дрожь)
TEXT_EFFECT(4, 4, 132) { // trigger #040484
    apply_shaking_movement();
    apply_fire();
    override_text_color(rgb(255, 61, 76));
    override_shadow_color(rgb(102, 17, 31));
}

// 34 — #040488  (Лавовый пульс)
TEXT_EFFECT(4, 4, 136) { // trigger #040488
    apply_fire();
    apply_growing_movement(1.3);
    override_text_color(rgb(255, 61, 0));
    override_shadow_color(rgb(120, 20, 0));
}

// 35 — #04048C  (Магма-рывок)
TEXT_EFFECT(4, 4, 140) { // trigger #04048C
    apply_fire();
    apply_shaking_movement();
    override_text_color(rgb(255, 69, 0));
    override_shadow_color(rgb(120, 30, 0));
}

// 36 — #040490  (Солнечная вспышка)
TEXT_EFFECT(4, 4, 144) { // trigger #040490
    apply_fire();
    apply_shaking_movement();
    apply_growing_movement(1.1);
    override_text_color(rgb(255, 111, 0));
    override_shadow_color(rgb(120, 40, 0));
}

// 37 — #040494  (Лавовые трещины)
TEXT_EFFECT(4, 4, 148) { // trigger #040494
    apply_fire();
    apply_shimmer(1.3, 0.5);
    apply_outline(rgb(120, 20, 0));
    apply_waving_movement(1.0, 1.7);
    override_text_color(rgb(255, 53, 0));
    override_shadow_color(rgb(110, 25, 0));
}

// ============================================
// Категория: Сложные и анимированные эффекты (38-68)
// ============================================

// 38 — #040498  (Пульсирующий синий)
TEXT_EFFECT(4, 4, 152) { // trigger #040498
    apply_growing_movement(1.5);
    override_text_color(rgb(40, 120, 255));
    override_shadow_color(rgb(10, 30, 80));
}

// 39 — #04049C  (Танцующий лайм)
TEXT_EFFECT(4, 4, 156) { // trigger #04049C
    apply_skewing_movement(1.3);
    override_text_color(rgb(120, 255, 80));
    override_shadow_color(rgb(30, 80, 20));
}

// 40 — #0404A0  (Волна океана)
TEXT_EFFECT(4, 4, 160) { // trigger #0404A0
    apply_waving_movement(1.5, 2.5);
    override_text_color(rgb(0, 200, 255));
    override_shadow_color(rgb(0, 60, 80));
}

// 41 — #0404A4  (Мигающий фиолетовый)
TEXT_EFFECT(4, 4, 164) { // trigger #0404A4
    apply_blinking(1.2);
    override_text_color(rgb(160, 32, 240));
    override_shadow_color(rgb(50, 10, 80));
}

// 42 — #0404A8  (Красная дрожь)
TEXT_EFFECT(4, 4, 168) { // trigger #0404A8
    apply_shaking_movement();
    override_text_color(rgb(255, 61, 76));
    override_shadow_color(rgb(102, 17, 31));
}

// 43 — #0404AC  (Красный металлик с обводкой)
TEXT_EFFECT(4, 4, 172) { // trigger #0404AC
    apply_shimmer(0.3, 0.4);
    apply_outline(rgb(139, 45, 45));
    apply_metalic(rgb(254, 110, 110));
    override_text_color(rgb(227, 70, 70));
}

// 44 — #0404B0  (Зелёный металлик с обводкой)
TEXT_EFFECT(4, 4, 176) { // trigger #0404B0
    apply_shimmer(0.3, 0.4);
    apply_outline(rgb(36, 140, 52));
    apply_metalic(rgb(160, 245, 173));
    override_text_color(rgb(137, 214, 85));
}

// 45 — #0404B4  (Неоновая мята)
TEXT_EFFECT(4, 4, 180) { // trigger #0404B4
    apply_glowing();
    apply_shimmer(0.9, 0.4);
    apply_thin_outline(rgb(0, 120, 70));
    override_text_color(rgb(0, 255, 136));
    override_shadow_color(rgb(0, 60, 40));
}

// 46 — #0404B8  (Кибер-аква)
TEXT_EFFECT(4, 4, 184) { // trigger #0404B8
    apply_chromatic_abberation();
    apply_shimmer(0.9, 0.6);
    override_text_color(rgb(0, 255, 213));
    override_shadow_color(rgb(0, 80, 80));
}

// 47 — #0404bc  (Кислый лайм)
TEXT_EFFECT(4, 4, 188) {
    apply_waving_movement(1.8, 2.8);
    apply_thin_outline(rgb(60, 120, 0));
    override_text_color(rgb(182, 255, 0));
    override_shadow_color(rgb(40, 80, 0));
}

// 48 — #0404C0  (Гипер-розовый)
TEXT_EFFECT(4, 4, 192) { // trigger #0404C0
    apply_flipping_movement(1.0, 1.5);
    apply_shimmer(1.0, 0.4);
    apply_outline(rgb(120, 0, 100));
    override_text_color(rgb(255, 0, 230));
    override_shadow_color(rgb(80, 0, 60));
}

// 49 — #0404C4  (Небесный рывок)
TEXT_EFFECT(4, 4, 196) { // trigger #0404C4
    apply_iterating_movement(1.2, 1.2);
    apply_gradient(rgb(100, 200, 255), rgb(0, 120, 255));
    override_shadow_color(rgb(0, 50, 90));
}

// 50 — #0408c8  (Электрофиолет)
TEXT_EFFECT(4, 8, 200) {
    apply_gradient(rgb(138, 43, 226), rgb(0, 220, 255));
    apply_thin_outline(rgb(40, 15, 80));
    override_shadow_color(rgb(30, 10, 50));
}

// 51 — #0404CC  (Сахарная вата)
TEXT_EFFECT(4, 4, 204) { // trigger #0404CC
    apply_waving_movement(1.3, 0.8);
    apply_gradient(rgb(255, 150, 235), rgb(220, 120, 255));
    override_shadow_color(rgb(70, 40, 90));
}

// 52 — #0404D0  (Матрица)
TEXT_EFFECT(4, 4, 208) { // trigger #0404D0
    apply_growing_movement(1.8);
    apply_vertical_shadow();
    apply_outline(rgb(0, 100, 0));
    override_text_color(rgb(0, 255, 26));
    override_shadow_color(rgb(0, 50, 10));
}

// 53 — #0404D4  (Янтарная дрожь)
TEXT_EFFECT(4, 4, 212) { // trigger #0404D4
    apply_shaking_movement();
    apply_gradient(rgb(255, 200, 120), rgb(255, 120, 0));
    override_shadow_color(rgb(90, 40, 0));
}

// 54 — #0404D8  (Аркана)
TEXT_EFFECT(4, 4, 216) { // trigger #0404D8
    apply_fade(rgb(255, 200, 255));
    apply_shimmer(0.8, 0.4);
    override_text_color(rgb(156, 39, 176));
    override_shadow_color(rgb(60, 20, 70));
}

// 55 — #0404DC  (Ледник)
TEXT_EFFECT(4, 4, 220) { // trigger #0404DC
    apply_glowing();
    apply_shimmer(1.4, 0.4);
    override_text_color(rgb(0, 255, 250));
    override_shadow_color(rgb(0, 70, 80));
}

// 56 — #0404E0  (Алая вспышка)
TEXT_EFFECT(4, 4, 224) { // trigger #0404E0
    apply_blinking(1.5);
    apply_thin_outline(rgb(100, 0, 20));
    override_text_color(rgb(255, 23, 68));
    override_shadow_color(rgb(60, 0, 20));
}

// 57 — #0404E4  (Весенний неон)
TEXT_EFFECT(4, 4, 228) { // trigger #0404E4
    apply_iterating_movement(0.9, 1.6);
    apply_outline(rgb(60, 120, 0));
    override_text_color(rgb(124, 252, 0));
    override_shadow_color(rgb(40, 80, 0));
}

// 58 — #0404E8  (Бирюзовая волна)
TEXT_EFFECT(4, 4, 232) { // trigger #0404E8
    apply_waving_movement(1.2, 1.6);
    apply_shimmer(0.8, 0.5);
    override_text_color(rgb(64, 224, 208));
    override_shadow_color(rgb(30, 90, 90));
}

// 59 — #0404EC  (Розовый туман)
TEXT_EFFECT(4, 4, 236) { // trigger #0404EC
    apply_fade(rgb(255, 220, 240));
    apply_gradient(rgb(240, 140, 180), rgb(210, 90, 140));
    override_shadow_color(rgb(80, 40, 60));
}

// 60 — #0404F0  (Сапфировое свечение)
TEXT_EFFECT(4, 4, 240) { // trigger #0404F0
    apply_metalic(rgb(180, 210, 255), rgb(60, 90, 140));
    apply_glowing();
    override_text_color(rgb(74, 144, 226));
    override_shadow_color(rgb(30, 60, 90));
}

// 61 — #0404F4  (Северное сияние)
TEXT_EFFECT(4, 4, 244) { // trigger #0404F4
    apply_gradient(rgb(50, 255, 180), rgb(120, 90, 255));
    apply_waving_movement(1.4, 2.2);
    apply_shimmer(0.8, 0.35);
    apply_thin_outline(rgb(30, 120, 120));
    override_shadow_color(rgb(20, 50, 80));
}

// 62 — #0404F8  (Ледяные кристаллы)
TEXT_EFFECT(4, 4, 248) { // trigger #0404F8
    apply_fire();
    apply_shimmer(1.3, 0.5);
    apply_outline(rgb(120, 180, 2550));
    apply_waving_movement(1.0, 1.7);
    override_text_color(rgb(158, 232, 255));
    override_shadow_color(rgb(40, 80, 110));
}

// 63 — #0404FC  (Глитч-магента)
TEXT_EFFECT(4, 4, 252) { // trigger #0404FC
    apply_chromatic_abberation();
    apply_shaking_movement();
    apply_flipping_movement(1.0, 1.4);
    apply_shimmer(0.5, 0.35);
    override_text_color(rgb(255, 0, 168));
    override_shadow_color(rgb(90, 0, 60));
}


// 64 — #0408ff (Туманность)
TEXT_EFFECT(4, 8, 255) { 
    apply_gradient(rgb(80, 0, 255), rgb(0, 220, 255));
    apply_thin_outline(rgb(40, 0, 90));
    override_shadow_color(rgb(20, 30, 80));
}

// 65 — #040cff  (Морозное дыхание)
TEXT_EFFECT(4, 12, 255) { 
    apply_iterating_movement(2.0, 1.3);
    apply_waving_movement(0.9, 1.2);
    apply_shimmer(1.4, 0.5);
    apply_glowing();
    apply_thin_outline(rgb(0, 160, 160));
    override_text_color(rgb(160, 255, 230));
    override_shadow_color(rgb(20, 80, 80));
}

// 66 — #0410ff (Звездопад)
TEXT_EFFECT(4, 16, 255) { 
    apply_glowing();
    apply_shimmer(1.0, 0.7);
    // apply_growing_movement(1.2);
    apply_outline(rgb(160, 140, 60));
    override_text_color(rgb(255, 244, 163));
    override_shadow_color(rgb(100, 90, 50));
}

// 67 — #0414ff (Призменный импульс)
TEXT_EFFECT(4, 20, 255) { 
    apply_chromatic_abberation();
    apply_waving_movement(1.3, 2.0);
    apply_gradient(rgb(0, 255, 192), rgb(40, 190, 255));
    apply_shimmer(1.2, 0.5);
    override_shadow_color(rgb(0, 80, 90));
}